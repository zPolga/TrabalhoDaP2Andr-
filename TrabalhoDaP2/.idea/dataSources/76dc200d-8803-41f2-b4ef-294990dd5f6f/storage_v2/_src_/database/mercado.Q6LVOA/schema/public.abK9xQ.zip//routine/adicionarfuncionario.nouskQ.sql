create function adicionarfuncionario() returns trigger
    language plpgsql
as
$$
BEGIN		
	UPDATE estoque
	SET est_atual = est_anterior - NEW.estoque_atual
	WHERE id_estoque = NEW.id_estoque;
	RETURN NEW;
END;
$$;

alter function adicionarfuncionario() owner to postgres;

